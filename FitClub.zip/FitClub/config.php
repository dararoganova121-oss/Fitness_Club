<?php
declare(strict_types=1);

header('Content-Type: text/html; charset=utf-8');
date_default_timezone_set('Europe/Moscow');

$dbHost = 'localhost';
$dbName = 'fitness_club';
$dbUser = 'root';
$dbPass = '1234';

const ADMIN_EMAIL = 'admin@fitness.local';
const ADMIN_PASSWORD = 'admin123';

try {
    $pdo = new PDO(
        "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
    $pdo->exec("SET NAMES utf8mb4");
    $pdo->exec("SET CHARACTER SET utf8mb4");
} catch (PDOException $e) {
    http_response_code(500);
    echo '<!doctype html><html lang="ru"><head><meta charset="UTF-8"><title>Ошибка БД</title><style>body{font-family:Arial;padding:32px;background:#F7EDE2;color:#263238}.alert{max-width:760px;background:#fff;border-left:5px solid #F28482;padding:18px;border-radius:10px}</style></head><body>';
    echo '<div class="alert"><h2>Ошибка подключения к базе данных</h2><p>Проверьте импорт database.sql и параметры подключения в config.php.</p><p>' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</p></div>';
    echo '</body></html>';
    exit;
}
