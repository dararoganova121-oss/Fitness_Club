SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

CREATE DATABASE fitness_club
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE fitness_club;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS session_bookings;
DROP TABLE IF EXISTS group_sessions;
DROP TABLE IF EXISTS subscriptions;
DROP TABLE IF EXISTS subscription_types;
DROP TABLE IF EXISTS trainers;
DROP TABLE IF EXISTS clients;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE clients (
    id_client INT AUTO_INCREMENT PRIMARY KEY,
    last_name VARCHAR(100) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    birth_date DATE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE trainers (
    id_trainer INT AUTO_INCREMENT PRIMARY KEY,
    last_name VARCHAR(100) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    specialization VARCHAR(255) NOT NULL,
    experience INT NOT NULL DEFAULT 0,
    education VARCHAR(255),
    bio TEXT,
    photo_url VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE subscription_types (
    id_subscription_type INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    duration_days INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    description TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE subscriptions (
    id_subscription INT AUTO_INCREMENT PRIMARY KEY,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    id_client INT NOT NULL,
    id_subscription_type INT NOT NULL,
    CONSTRAINT fk_sub_client FOREIGN KEY (id_client) REFERENCES clients(id_client) ON DELETE CASCADE,
    CONSTRAINT fk_sub_type FOREIGN KEY (id_subscription_type) REFERENCES subscription_types(id_subscription_type) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE group_sessions (
    id_group_session INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    session_datetime DATETIME NOT NULL,
    id_trainer INT NOT NULL,
    id_subscription_type INT NOT NULL,
    CONSTRAINT fk_session_trainer FOREIGN KEY (id_trainer) REFERENCES trainers(id_trainer) ON DELETE CASCADE,
    CONSTRAINT fk_session_type FOREIGN KEY (id_subscription_type) REFERENCES subscription_types(id_subscription_type) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE payments (
    id_payment INT AUTO_INCREMENT PRIMARY KEY,
    amount DECIMAL(10,2) NOT NULL,
    payment_date DATETIME NOT NULL,
    is_paid TINYINT(1) NOT NULL DEFAULT 0,
    id_client INT NOT NULL,
    id_subscription INT NOT NULL,
    CONSTRAINT fk_payment_client FOREIGN KEY (id_client) REFERENCES clients(id_client) ON DELETE CASCADE,
    CONSTRAINT fk_payment_subscription FOREIGN KEY (id_subscription) REFERENCES subscriptions(id_subscription) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE session_bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT NOT NULL,
    group_session_id INT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_client_session (client_id, group_session_id),
    CONSTRAINT fk_booking_client FOREIGN KEY (client_id) REFERENCES clients(id_client) ON DELETE CASCADE,
    CONSTRAINT fk_booking_session FOREIGN KEY (group_session_id) REFERENCES group_sessions(id_group_session) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO clients (last_name, first_name, middle_name, email, password, phone, birth_date) VALUES
('Иванова', 'Мария', 'Сергеевна', 'maria@example.com', '$2y$12$u9KG/SzcWEosEwP7Tps2PusLefMYEHepF3k69QTFBCGUT9ZidWrdy', '+7 (900) 111-22-33', '1998-04-12'),
('Петрова', 'Анна', 'Игоревна', 'anna@example.com', '$2y$12$u9KG/SzcWEosEwP7Tps2PusLefMYEHepF3k69QTFBCGUT9ZidWrdy', '+7 (900) 222-33-44', '1995-09-03'),
('Смирнов', 'Дмитрий', 'Олегович', 'dmitry@example.com', '$2y$12$u9KG/SzcWEosEwP7Tps2PusLefMYEHepF3k69QTFBCGUT9ZidWrdy', '+7 (900) 333-44-55', '1992-12-20'),
('Кузнецова', 'Елена', 'Павловна', 'elena@example.com', '$2y$12$u9KG/SzcWEosEwP7Tps2PusLefMYEHepF3k69QTFBCGUT9ZidWrdy', '+7 (900) 444-55-66', '2000-01-18');

INSERT INTO trainers (last_name, first_name, middle_name, specialization, experience, education, bio, photo_url) VALUES
('Урулина', 'Ксения', 'Александровна', 'пилатес, стретчинг, бачата, зумба, хай хиллс', 6, 'высшее спортивное ВлГУ, сертификат международного уровня ISSA', 'О себе: помогает девушкам обрести гибкость, пластичность и полюбить себя. Работает с новичками и опытными атлетами. Строит программы с учётом особенностей здоровья и целей клиента. Достижения: призер соревнований по спортивным танцам и художественной гимнастике.', 'assets/trainer-ksenia.svg'),
('Роганова', 'Дарья', 'Анатольевна', 'дзюдо, самбо, борьба на поясах', 14, 'высшее спортивное РГУФК, сертификат международного уровня ISSA', 'О себе: тренировки для девушек — сочетание самообороны и физической подготовки без изнурительных нагрузок. Помогает преодолеть страх, поверить в свои силы и освоить эффективные приёмы защиты. Достижения: мастер спорта по борьбе на поясах, разрядник по самбо и дзюдо, призер мира по борьбе на поясах, призер многочисленных соревнований.', 'assets/trainer-daria.svg');

INSERT INTO subscription_types (name, duration_days, price, description) VALUES
('Роскошный максимум', 30, 10000.00, 'Что входит: безлимитное посещение тренажёрного зала и всех групповых занятий; доступ в зону релаксации и SPA: сауна, хаммам, бассейн; консультация диетолога — 1 раз в месяц; замер антропометрических данных; приоритетная запись на популярные занятия.'),
('Золотая середина', 30, 7000.00, 'Что входит: безлимитное посещение тренажёрного зала и всех групповых занятий; использование раздевалок, душевых, шкафчиков; замер антропометрических данных; онлайн-поддержка тренера в мессенджере.'),
('Базовый минимум', 30, 4000.00, 'Что входит: безлимитное посещение всех групповых занятий; использование раздевалок и душевых; вводный инструктаж по работе с тренажёрами.');

INSERT INTO subscriptions (start_date, end_date, id_client, id_subscription_type) VALUES
('2026-05-01', '2026-05-30', 1, 1),
('2026-05-03', '2026-06-01', 2, 2),
('2026-04-20', '2026-05-19', 3, 3),
('2026-05-05', '2026-06-03', 4, 2);

INSERT INTO group_sessions (name, session_datetime, id_trainer, id_subscription_type) VALUES
('Пилатес', '2026-05-11 09:00:00', 1, 3),
('Пилатес', '2026-05-11 18:00:00', 1, 3),
('Пилатес', '2026-05-12 09:00:00', 1, 3),
('Пилатес', '2026-05-12 18:00:00', 1, 3),
('Пилатес', '2026-05-13 09:00:00', 1, 3),
('Пилатес', '2026-05-13 18:00:00', 1, 3),
('Пилатес', '2026-05-14 09:00:00', 1, 3),
('Пилатес', '2026-05-14 18:00:00', 1, 3),
('Пилатес', '2026-05-15 09:00:00', 1, 3),
('Пилатес', '2026-05-15 18:00:00', 1, 3),
('Пилатес', '2026-05-16 09:00:00', 1, 3),
('Пилатес', '2026-05-16 18:00:00', 1, 3),
('Стретчинг', '2026-05-11 20:00:00', 1, 3),
('Стретчинг', '2026-05-12 20:00:00', 1, 3),
('Стретчинг', '2026-05-13 20:00:00', 1, 3),
('Стретчинг', '2026-05-14 20:00:00', 1, 3),
('Стретчинг', '2026-05-15 20:00:00', 1, 3),
('Стретчинг', '2026-05-16 20:00:00', 1, 3),
('Стретчинг', '2026-05-17 20:00:00', 1, 3),
('Бачата', '2026-05-11 17:00:00', 1, 2),
('Бачата', '2026-05-13 17:00:00', 1, 2),
('Хай хиллс', '2026-05-12 17:00:00', 1, 2),
('Зумба', '2026-05-14 17:00:00', 1, 2),
('Зумба', '2026-05-16 10:00:00', 1, 2),
('Хай хиллс', '2026-05-16 12:00:00', 1, 2),
('Самбо', '2026-05-12 19:00:00', 2, 3),
('Самбо', '2026-05-14 19:00:00', 2, 3),
('Дзюдо', '2026-05-11 19:00:00', 2, 3),
('Дзюдо', '2026-05-12 19:00:00', 2, 3),
('Дзюдо', '2026-05-13 19:00:00', 2, 3),
('Дзюдо', '2026-05-15 17:00:00', 2, 3),
('Борьба на поясах', '2026-05-11 15:00:00', 2, 2),
('Борьба на поясах', '2026-05-12 15:00:00', 2, 2),
('Борьба на поясах', '2026-05-13 15:00:00', 2, 2),
('Борьба на поясах', '2026-05-14 15:00:00', 2, 2),
('Борьба на поясах', '2026-05-15 15:00:00', 2, 2),
('Борьба на поясах', '2026-05-16 15:00:00', 2, 2);

INSERT INTO payments (amount, payment_date, is_paid, id_client, id_subscription) VALUES
(10000.00, '2026-05-01 10:15:00', 1, 1, 1),
(7000.00, '2026-05-03 12:40:00', 1, 2, 2),
(4000.00, '2026-04-20 18:05:00', 1, 3, 3),
(7000.00, '2026-05-05 09:30:00', 1, 4, 4);

INSERT INTO session_bookings (client_id, group_session_id, created_at) VALUES
(1, 1, '2026-05-06 10:00:00'),
(1, 3, '2026-05-06 10:05:00'),
(2, 5, '2026-05-06 12:10:00'),
(4, 15, '2026-05-06 15:20:00');
